document.addEventListener("DOMContentLoaded", function(){

var modal = document.getElementById('myModal');
var menucheckbox = document.getElementById("menu_checkbox");
var menuicon = document.getElementById("menu_icon");
var menulist = document.querySelector(".menu_list");
var btns = document.querySelectorAll(".contact-btn");

// CONTACT //

btns.forEach(function(btn) { // AFFICHER LE MODAL CONTACT
    btn.addEventListener('click', function() {
        modal.style.visibility = "visible";
        modal.style.animation = "fadeIn 0.8s ease-in-out forwards";
        if(menucheckbox && menulist){        
            menulist.style.display = 'none';
            menucheckbox.checked=false;
            menuicon.src = burger;
        }
    });
});

window.addEventListener('click', function(event){ // FERMETURE LE MODAL CONTACT
    if (event.target == modal) {
        modal.style.animation = "fadeOut 1s ease-in-out forwards";
        modal.addEventListener('animationend', function onAnimationEnd(){
            modal.style.visibility = "hidden";
            modal.removeEventListener('animationend', onAnimationEnd);
          });
    }
});

// MENU BURGER //

menucheckbox.addEventListener('change', function(){ // NAVBAR RESPONSIVE
    if(menucheckbox.checked){ // SI LE BURGER EST COCHÉ
        menuicon.src = cross;
        menulist.style.animation = 'menu_opening 1s forwards';
        menulist.style.display = 'flex';
            menulist.addEventListener('animationend', function onAnimationEnd(){
            })
    }
    else{
        menuicon.src = burger;
        menulist.style.animation = 'menu_closing 1s forwards';
            menulist.addEventListener('animationend', function onAnimationEnd(){
                menulist.style.display = 'none';
            menulist.removeEventListener('animationend', onAnimationEnd);
            });
    }
})
  
$(document).ready(function() {
var selects = $('select');
    $('#categories-select, #formats-select, #tri-select').select2();

selects.each(function(){

    var select = $(this);
    var Open = false; // SI LE SELECT EST OUVERT
    var arrow_down = select.siblings('.fa-chevron-down');
    var arrow_up = select.siblings('.fa-chevron-up');
    function isOpen(){
        if(Open){
            arrow_up.css('opacity', '1');
            arrow_down.css('opacity', '0');
        }
        else{
            arrow_up.css('opacity', '0');
            arrow_down.css('opacity', '1');
        }
    }
    select.on('mousedown', function(){
            Open = !Open;
            isOpen();
    })
    $(document).on('mousedown', function(event) {
        if (!select.is(event.target) && select.has(event.target).length === 0) {
            Open = false;
            isOpen();
        }
    });
});
});


});
