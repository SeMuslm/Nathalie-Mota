<div class="lightbox">
    <img class="eye_icon" src="<?php echo get_template_directory_uri() . "/images/Icons/Icon_eye.png"; ?>" alt="">
    <img class="fullscreen_icon" src="<?php echo get_template_directory_uri() . "/images/Icons/Icon_fullscreen.png"; ?>" alt="">
</div>